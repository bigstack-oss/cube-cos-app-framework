{{- define "cube.eventlistener.validate" -}}
{{- if not .Values.eventListener.jarFileName -}}
{{- fail "eventListener.jarFileName must not be empty" -}}
{{- end -}}
{{- if not .Values.eventListener.webhookUrl -}}
{{- fail "eventListener.webhookUrl must not be empty" -}}
{{- end -}}
{{- end -}}
