{{/*
cmp-group-rotation-check (spi/rotation) config validation. Bad values (a typo'd duration, an
empty group name) previously only surfaced as RotationPolicy.parse() throwing out of the SPI's
init() at Keycloak container startup -- this fails `helm template`/`install`/`upgrade` instead,
before anything is deployed. See keycloak-values.yaml's `rotation` block and cubecmp#1106.
*/}}
{{- define "cube.rotation.validate" -}}
{{- if not .Values.rotation.exemptGroup -}}
{{- fail "rotation.exemptGroup must not be empty" -}}
{{- end -}}
{{- if not (regexMatch "^([0-9]+[smhd]|exempt)$" .Values.rotation.defaultMaxAge) -}}
{{- fail (printf "rotation.defaultMaxAge %q is not a valid duration (expected \"exempt\" or a number with an s/m/h/d suffix)" .Values.rotation.defaultMaxAge) -}}
{{- end -}}
{{- if not .Values.rotation.jarFileName -}}
{{- fail "rotation.jarFileName must not be empty" -}}
{{- end -}}
{{- end -}}
